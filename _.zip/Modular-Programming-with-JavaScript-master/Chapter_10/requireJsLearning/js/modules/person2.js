// none AMD module
var person2 = {
    first: "Fay",
    last: "FayLastName"
};