// none AMD module
var person4 = (function() {
    return {
        first: "Tim",
        last: "TimLastName"
    };
})();